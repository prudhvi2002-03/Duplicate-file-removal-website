const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../Frontend')));

// Multer setup for file uploads
const upload = multer({ dest: 'uploads/' });

// Dummy scan endpoint for phone files
app.post('/api/scan', (req, res) => {
    // TODO: Implement actual scan logic
    res.json({
        duplicates: [
            // Example response
            // { name: 'file1.jpg', path: '/photos/file1.jpg', size: '1.2 MB', date: '2024-06-20', original: true },
            // { name: 'file1.jpg', path: '/photos/backup/file1.jpg', size: '1.2 MB', date: '2024-06-19', original: false }
        ]
    });
});

// Scan uploaded files (from OneDrive/PC)
app.post('/api/scan-uploads', upload.array('files'), (req, res) => {
    // TODO: Implement actual scan logic for uploaded files
    res.json({
        duplicates: []
    });
});

// Delete files endpoint
app.post('/api/delete-files', (req, res) => {
    const { filesToDelete } = req.body;
    // TODO: Implement actual deletion logic
    // For now, just return success
    res.json({ success: true, deleted: filesToDelete });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});

// Replace your existing script with this updated version

// Track selected files from OneDrive/PC
let selectedFiles = [];
let currentSource = 'phone';
let currentFileType = '';
let filesToDelete = [];

// API configuration
const API_BASE_URL = 'http://localhost:3000/api';

async function fetchWithTimeout(resource, options = {}) {
    const { timeout = 8000 } = options;
    
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    
    const response = await fetch(resource, {
        ...options,
        signal: controller.signal  
    });
    clearTimeout(id);
    
    return response;
}

function selectSource(source) {
    currentSource = source;
    document.getElementById('phoneBtn').classList.toggle('active', source === 'phone');
    document.getElementById('onedriveBtn').classList.toggle('active', source === 'onedrive');
    document.getElementById('phoneContent').style.display = source === 'phone' ? 'block' : 'none';
    document.getElementById('onedriveContent').style.display = source === 'onedrive' ? 'block' : 'none';
}

function handleFileSelection(files) {
    selectedFiles = Array.from(files);
    const selectedFilesContainer = document.getElementById('selectedFiles');
    selectedFilesContainer.innerHTML = '';
    
    if (selectedFiles.length === 0) {
        document.getElementById('scanBtn').disabled = true;
        return;
    }
    
    // Display selected files
    selectedFiles.forEach(file => {
        const fileElement = document.createElement('div');
        fileElement.className = 'selected-file';
        fileElement.innerHTML = `
            <span>${file.name}</span>
            <span>${formatFileSize(file.size)}</span>
        `;
        selectedFilesContainer.appendChild(fileElement);
    });
    
    document.getElementById('scanBtn').disabled = false;
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

async function scanSelectedFiles() {
    document.getElementById('scanTypeHeader').textContent = "Selected Files";
    const modal = document.getElementById('scanningModal');
    modal.style.display = 'flex';
    
    const progress = document.getElementById('scanProgress');
    const message = document.getElementById('scanningMessage');
    
    // Simulate progress
    let progressValue = 0;
    const progressInterval = setInterval(() => {
        progressValue += 5;
        progress.style.width = progressValue + '%';
        
        if (progressValue < 30) {
            message.textContent = 'Reading files...';
        } else if (progressValue < 70) {
            message.textContent = 'Comparing file contents...';
        } else {
            message.textContent = 'Identifying duplicates...';
        }
    }, 100);
    
    try {
        // Prepare FormData for file upload
        const formData = new FormData();
        selectedFiles.forEach(file => {
            formData.append('files', file);
        });
        
        // Send files to backend for scanning
        const response = await fetchWithTimeout(`${API_BASE_URL}/scan-uploads`, {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        clearInterval(progressInterval);
        progress.style.width = '100%';
        
        setTimeout(() => {
            closeModal('scanningModal');
            displayResults(data.duplicates, "Selected Files");
        }, 500);
    } catch (error) {
        console.error('Error scanning files:', error);
        clearInterval(progressInterval);
        message.textContent = 'Error scanning files';
        progress.style.backgroundColor = 'var(--danger-color)';
        
        setTimeout(() => {
            closeModal('scanningModal');
            alert('Error scanning files. Please try again.');
        }, 1500);
    }
}

async function showScanModal(type) {
    if (currentSource !== 'phone') return;
    
    currentFileType = type;
    document.getElementById('scanTypeHeader').textContent = type;
    const modal = document.getElementById('scanningModal');
    modal.style.display = 'flex';
    
    const progress = document.getElementById('scanProgress');
    const message = document.getElementById('scanningMessage');
    
    // Simulate progress
    let progressValue = 0;
    const progressInterval = setInterval(() => {
        progressValue += 5;
        progress.style.width = progressValue + '%';
        
        if (progressValue < 30) {
            message.textContent = 'Finding files...';
        } else if (progressValue < 70) {
            message.textContent = 'Comparing files...';
        } else {
            message.textContent = 'Identifying duplicates...';
        }
    }, 100);
    
    try {
        // Call backend API to scan files
        const response = await fetchWithTimeout(`${API_BASE_URL}/scan`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ fileType: type })
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        clearInterval(progressInterval);
        progress.style.width = '100%';
        
        setTimeout(() => {
            closeModal('scanningModal');
            displayResults(data.duplicates, type);
        }, 500);
    } catch (error) {
        console.error('Error scanning files:', error);
        clearInterval(progressInterval);
        message.textContent = 'Error scanning files';
        progress.style.backgroundColor = 'var(--danger-color)';
        
        setTimeout(() => {
            closeModal('scanningModal');
            alert('Error scanning files. Please try again.');
        }, 1500);
    }
}

function displayResults(duplicates, type) {
    document.getElementById('resultsTypeHeader').textContent = type;
    const resultsContent = document.getElementById('resultsContent');
    resultsContent.innerHTML = '';
    
    if (!duplicates || duplicates.length === 0) {
        resultsContent.innerHTML = '<p>No duplicate files found.</p>';
        document.querySelector('#resultsModal .modal-footer').style.display = 'none';
        document.getElementById('resultsModal').style.display = 'flex';
        return;
    }
    
    // Reset files to delete
    filesToDelete = [];
    
    // Group files by name for display
    const fileGroups = {};
    duplicates.forEach(file => {
        if (!fileGroups[file.name]) {
            fileGroups[file.name] = [];
        }
        fileGroups[file.name].push(file);
    });
    
    // Create HTML for each file group
    for (const [fileName, files] of Object.entries(fileGroups)) {
        if (files.length > 1) { // Only show groups with duplicates
            const groupHeader = document.createElement('div');
            groupHeader.style.fontWeight = 'bold';
            groupHeader.style.margin = '15px 0 5px 0';
            groupHeader.textContent = `${fileName} (${files.length} files)`;
            resultsContent.appendChild(groupHeader);
            
            files.forEach(file => {
                const fileItem = document.createElement('div');
                fileItem.className = 'file-item';
                
                const radioId = `${fileName}-${file.path.replace(/\W/g, '-')}`;
                
                fileItem.innerHTML = `
                    <input type="radio" id="${radioId}" name="${fileName}" 
                           ${file.original ? 'checked' : ''}
                           data-path="${file.path}" 
                           data-size="${file.size.split(' ')[0]}">
                    <div class="file-info">
                        <div class="file-name">${file.path}${file.name}
                            ${file.original ? '<span class="original-badge">ORIGINAL</span>' : ''}
                        </div>
                        <div class="file-details">${file.size} • ${file.date}</div>
                    </div>
                `;
                
                // Add event listener to track selections
                const radio = fileItem.querySelector('input[type="radio"]');
                radio.addEventListener('change', () => {
                    if (!radio.checked && !file.original) {
                        filesToDelete.push(file.path);
                    } else if (radio.checked && file.original) {
                        filesToDelete = filesToDelete.filter(path => path !== file.path);
                    }
                });
                
                // Initially add non-original files to delete list
                if (!file.original && !files.some(f => f.original && f.name === file.name)) {
                    filesToDelete.push(file.path);
                }
                
                resultsContent.appendChild(fileItem);
            });
        }
    }
    
    // Show the modal and ensure footer is visible
    document.querySelector('#resultsModal .modal-footer').style.display = 'flex';
    document.getElementById('resultsModal').style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

async function deleteDuplicates() {
    // Count how many files would be deleted and their total size
    let deleteCount = filesToDelete.length;
    let deleteSize = 0;
    
    // Calculate total size (simplified for demo)
    document.querySelectorAll('input[type="radio"]:not(:checked)').forEach(radio => {
        const size = parseFloat(radio.dataset.size) || 0;
        deleteSize += size;
    });
    
    document.getElementById('deleteCount').textContent = deleteCount;
    document.getElementById('deleteSize').textContent = deleteSize.toFixed(2) + ' MB';
    
    closeModal('resultsModal');
    document.getElementById('confirmModal').style.display = 'flex';
}

async function confirmDeletion() {
    const confirmModal = document.getElementById('confirmModal');
    confirmModal.querySelector('.modal-body').innerHTML = `
        <div class="progress-bar">
            <div class="progress" id="deletionProgress"></div>
        </div>
        <p>Deleting files...</p>
    `;
    
    const progress = confirmModal.querySelector('#deletionProgress');
    let progressValue = 0;
    const progressInterval = setInterval(() => {
        progressValue += 10;
        progress.style.width = progressValue + '%';
    }, 100);
    
    try {
        // Call backend API to delete files
        const response = await fetchWithTimeout(`${API_BASE_URL}/delete-files`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ filesToDelete })
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        clearInterval(progressInterval);
        progress.style.width = '100%';
        
        setTimeout(() => {
            closeModal('confirmModal');
            alert(`${filesToDelete.length} files deleted successfully!`);
            
            // Reset the UI
            filesToDelete = [];
            if (currentSource === 'phone') {
                showScanModal(currentFileType);
            } else {
                // For OneDrive/PC, clear the selection
                document.getElementById('fileInput').value = '';
                document.getElementById('selectedFiles').innerHTML = '';
                document.getElementById('scanBtn').disabled = true;
                selectedFiles = [];
            }
        }, 500);
    } catch (error) {
        console.error('Error deleting files:', error);
        clearInterval(progressInterval);
        confirmModal.querySelector('.modal-body').innerHTML = `
            <p>Error deleting files. Please try again.</p>
        `;
        
        setTimeout(() => {
            closeModal('confirmModal');
        }, 2000);
    }
}
